
<!-- BOOTSTRAP 5 -->	
<script src="assets/js/bootstrap.min.js"></script> 
<!-- BOOTSTRAP 5 -->	
<!-- JQUERY  -->	
<script src="assets/js/jquery-3.6.0.min.js"></script>
<!-- JQUERY  -->	
<!-- RESPONSIVE NAVIFATION -->
<script src="assets/js/stellarnav.min.js"></script>
<!-- RESPONSIVE NAVIFATION -->
<!-- SWIPER SLIDER -->
<script src="assets/js/swiper-bundle.min.js"></script>
<!-- SWIPER SLIDER -->
<!-- FANCY BOX IMAGE VIEWER -->
<script src="assets/js/jquery.fancybox.min.js"></script> 
<!-- FANCY BOX IMAGE VIEWER -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
<!-- CALENDER JS -->
<script src="assets/js/calendar.min.js"></script> 
<script src="assets/js/calendar.js"></script> 
<!-- JAVASCRIPT SHEETS -->
<script src="assets/js/custom.js"></script> 
<!-- JAVASCRIPT SHEETS -->




</body>
</html>